#!/usr/bin/env python3
"""Frozen geometry gate for curvature-adaptive log-loss recalibration."""

from __future__ import annotations

import json
import math
from dataclasses import asdict, dataclass

import numpy as np


EPSILONS = (0.2, 0.1, 0.05, 0.025, 0.0125)
RANDOM_CASES = 4000
SEED = 730_271


@dataclass
class GateRow:
    epsilon: float
    levels: int
    delta: float
    max_probability_gap: float
    max_tangent_gap: float
    clipping_cost: float
    worst_oracle_value: float
    worst_oracle_bound: float
    uniform_max_tangent_gap: float
    adaptive_gap_ratio: float
    uniform_gap_ratio: float


def bernoulli_kl(p: np.ndarray, q: np.ndarray) -> np.ndarray:
    return p * np.log(p / q) + (1.0 - p) * np.log(
        (1.0 - p) / (1.0 - q)
    )


def tangent_gaps(grid: np.ndarray) -> np.ndarray:
    p = grid[:-1]
    r = grid[1:]
    upper_orientation = bernoulli_kl(p, r) / p
    lower_orientation = bernoulli_kl(r, p) / (1.0 - r)
    return np.where(
        r <= 0.5,
        lower_orientation,
        np.where(
            p >= 0.5,
            upper_orientation,
            np.maximum(upper_orientation, lower_orientation),
        ),
    )


def adaptive_grid(epsilon: float) -> np.ndarray:
    eta = epsilon / 8.0
    span = math.pi / 2.0 - 2.0 * eta
    intervals = math.ceil(span / eta)
    theta = np.linspace(eta, math.pi / 2.0 - eta, intervals + 1)
    return np.sin(theta) ** 2


def best_adjacent_value(f0: np.ndarray, f1: np.ndarray) -> float:
    best = float(np.min(np.maximum(f0, f1)))
    d0 = f0[1:] - f0[:-1]
    d1 = f1[1:] - f1[:-1]
    denominator = d0 - d1
    numerator = f1[:-1] - f0[:-1]
    lam = np.divide(
        numerator,
        denominator,
        out=np.zeros_like(numerator),
        where=np.abs(denominator) > 1e-15,
    )
    lam = np.clip(lam, 0.0, 1.0)
    edge0 = f0[:-1] + lam * d0
    edge1 = f1[:-1] + lam * d1
    return min(best, float(np.min(np.maximum(edge0, edge1))))


def oracle_stress(
    grid: np.ndarray,
    max_gap: float,
    max_tangent_gap: float,
    epsilon: float,
    rng: np.random.Generator,
) -> tuple[float, float]:
    delta = float(grid[0])
    q_values = np.array(
        [delta, math.sqrt(delta), 0.1, 0.5, 0.9, 1.0 - math.sqrt(delta), 1.0 - delta]
    )
    q_values = np.clip(q_values, delta, 1.0 - delta)
    alpha_values = np.array(
        [0.0, epsilon**2, epsilon, 0.1, 0.5, 0.9, 1.0]
    )

    cases: list[tuple[float, float, np.ndarray]] = []
    patterns = (
        np.ones_like(grid),
        -np.ones_like(grid),
        np.where(np.arange(grid.size) % 2 == 0, 1.0, -1.0),
        np.linspace(-1.0, 1.0, grid.size),
        np.linspace(1.0, -1.0, grid.size),
    )
    for q in q_values:
        for alpha in alpha_values:
            for u in patterns:
                cases.append((float(q), float(alpha), u))

    for _ in range(RANDOM_CASES):
        q = float(rng.choice(q_values)) if rng.random() < 0.5 else float(
            rng.uniform(delta, 1.0 - delta)
        )
        alpha = (
            float(rng.choice(alpha_values))
            if rng.random() < 0.5
            else float(rng.uniform())
        )
        if rng.random() < 0.5:
            u = rng.choice(np.array([-1.0, 1.0]), size=grid.size)
        else:
            u = rng.uniform(-1.0, 1.0, size=grid.size)
        cases.append((q, alpha, u))

    worst_value = -float("inf")
    worst_bound = 0.0
    loss0_grid = -np.log1p(-grid)
    loss1_grid = -np.log(grid)
    for q, alpha, u in cases:
        beta = 1.0 - alpha
        f0 = alpha * u * grid + beta * (loss0_grid + math.log1p(-q))
        f1 = alpha * u * (grid - 1.0) + beta * (loss1_grid + math.log(q))
        value = best_adjacent_value(f0, f1)
        extended_mesh = max(max_gap, delta, 1.0 - float(grid[-1]))
        bound = alpha * extended_mesh + beta * max_tangent_gap
        worst_value = max(worst_value, value)
        worst_bound = max(worst_bound, bound)
        if value > bound + 2e-12:
            raise AssertionError(
                f"oracle bound failed: value={value}, bound={bound}, "
                f"epsilon={epsilon}, q={q}, alpha={alpha}"
            )
    return worst_value, worst_bound


def run() -> dict[str, object]:
    rng = np.random.default_rng(SEED)
    rows: list[GateRow] = []
    uniform_ratios: list[float] = []
    for epsilon in EPSILONS:
        grid = adaptive_grid(epsilon)
        delta = float(grid[0])
        probability_gaps = np.diff(grid)
        local_tangent_gaps = tangent_gaps(grid)
        max_probability_gap = float(np.max(probability_gaps))
        max_tangent_gap = float(np.max(local_tangent_gaps))
        clipping_cost = float(-math.log1p(-delta))

        uniform = np.linspace(delta, 1.0 - delta, grid.size)
        uniform_max_tangent_gap = float(np.max(tangent_gaps(uniform)))

        worst_value, worst_bound = oracle_stress(
            grid,
            max_probability_gap,
            max_tangent_gap,
            epsilon,
            rng,
        )

        row = GateRow(
            epsilon=epsilon,
            levels=int(grid.size),
            delta=delta,
            max_probability_gap=max_probability_gap,
            max_tangent_gap=max_tangent_gap,
            clipping_cost=clipping_cost,
            worst_oracle_value=worst_value,
            worst_oracle_bound=worst_bound,
            uniform_max_tangent_gap=uniform_max_tangent_gap,
            adaptive_gap_ratio=max_tangent_gap / epsilon**2,
            uniform_gap_ratio=uniform_max_tangent_gap / epsilon**2,
        )
        rows.append(row)
        uniform_ratios.append(row.uniform_gap_ratio)

        if row.levels > 16.0 / epsilon + 1:
            raise AssertionError(f"too many levels: {row}")
        if max_probability_gap > epsilon / 4.0 + 1e-12:
            raise AssertionError(f"probability gap failed: {row}")
        if max_tangent_gap > epsilon**2 / 8.0 + 1e-12:
            raise AssertionError(f"tangent gap failed: {row}")
        if clipping_cost > epsilon**2 / 32.0 + 1e-12:
            raise AssertionError(f"clipping cost failed: {row}")

    if not all(b > a for a, b in zip(uniform_ratios, uniform_ratios[1:])):
        raise AssertionError(
            f"uniform-grid tangent-gap ratios did not worsen: {uniform_ratios}"
        )

    return {
        "status": "pass",
        "seed": SEED,
        "random_cases_per_epsilon": RANDOM_CASES,
        "rows": [asdict(row) for row in rows],
    }


if __name__ == "__main__":
    print(json.dumps(run(), indent=2, sort_keys=True))
