# LogRecal supplement

This directory contains the implementation, deterministic checks, benchmark
drivers, and raw outputs for *Near-Optimal Online Recalibration for Log
Loss*. All reported forecasts are made before their corresponding labels
are revealed.

## Environment

The core implementation and controlled experiments require Python 3.10 or
newer and NumPy. The reported runs used Python 3.10.12, NumPy 2.2.6, and
scikit-learn 1.7.2. CIFAR feature extraction additionally requires PyTorch,
torchvision, and transformers.

## Deterministic checks

From this directory, run:

```bash
python3 test_algorithm.py
python3 test_baselines.py
python3 gate.py
```

The geometry gate checks 21,225 fixed and seeded random oracle inputs. Its
expected output contains `"status": "pass"`. `gate_result.json` records
the complete output used in the paper.

## Controlled experiments

The full commands are:

```bash
python3 benchmark_synthetic.py --epsilon 0.1 --rounds 30000 --seeds 5 \
  --output synthetic_result.json
python3 benchmark_frontier.py --epsilon 0.1 --rounds 30000 --seeds 5 \
  --streams severe_temperature boundary_shift \
  --multipliers 0.25 1 4 16 64 --output frontier_result.json
python3 benchmark_hops.py --epsilon 0.1 --rounds 30000 --passes 100 \
  --seeds 5 --flip-probability 0.2 --output hops_result.json
python3 benchmark_practical.py --epsilon 0.1 --multiplier 16 \
  --rounds 30000 --passes 100 --seeds 5 --flip-probability 0.2 \
  --output practical_result.json
```

The HOPS driver also runs the CIFAR experiment because it evaluates that
direct baseline on both suites. The practical driver evaluates the fixed
meta-step multiplier reported in the appendix.

## Shifted CIFAR-10 experiment

Generate the public frozen features with:

```bash
python3 prepare_cifar_features.py --output-dir features
export LOGRECAL_FEATURE_DIR="$PWD/features"
python3 benchmark_cifar2.py --epsilon 0.1 --passes 100 --seeds 5 \
  --flip-probability 0.2 --output cifar2_result.json
```

Feature extraction uses the training and test order supplied by torchvision
CIFAR-10 and the unnormalized output of the visual projection in
`openai/clip-vit-base-patch32`. The benchmark normalizes every feature to
unit Euclidean norm before fitting the logistic head. The arrays used for
the reported run had these SHA-256 digests:

```text
ffd11334afa08cc4db3e0fdcc496b117e6881a1ca1175888be5e5fa189a4f7f3  cifar10_train_clip_base_final.npy
9e2ee9261f6a7c6509b35aaa7161bf15d6d99673bbcac04130702d12a6da88d3  cifar10_train_labels.npy
d0e81eb4db86e37f04c3d989025a06a9e577b0769cdbbeb6de66784c22d1e63f  cifar10_test_clip_base_final.npy
fc48d9ecfdbeacce2dacf004498170f2df12e75e3485475017d2663b587a92f3  cifar10_test_labels.npy
```

The feature arrays are omitted from the supplement because they are about
118 MB and are deterministically regenerable from the cited public data and
model. All raw metric outputs are included.
