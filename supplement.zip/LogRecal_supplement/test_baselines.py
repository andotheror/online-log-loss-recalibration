#!/usr/bin/env python3
"""Deterministic smoke tests for direct empirical baselines."""

from __future__ import annotations

import numpy as np

from benchmark_synthetic import (
    online_sgd_platt_predictions,
    run_hops_sgd,
    run_online_platt,
)


def main() -> None:
    rng = np.random.default_rng(17)
    hints = np.resize(np.linspace(0.01, 0.99, 31), 2_000)
    labels = rng.binomial(1, 0.1 + 0.8 * hints)

    continuous = online_sgd_platt_predictions(hints, labels, 0.1)
    assert continuous.shape == hints.shape
    assert np.all(np.logical_and(continuous > 0.0, continuous < 1.0))

    platt = run_online_platt(hints, labels, 0.1)
    hops_a = run_hops_sgd(hints, labels, 0.1, seed=29)
    hops_b = run_hops_sgd(hints, labels, 0.1, seed=29)
    assert platt["unique_predictions"] > 1
    for key in hops_a:
        if key != "seconds":
            assert hops_a[key] == hops_b[key]
    assert 1 <= hops_a["unique_predictions"] <= 10
    assert np.isfinite(hops_a["mean_log_loss"])
    assert 0.0 <= hops_a["calibration_k1"] <= 1.0
    print("baseline smoke tests passed")


if __name__ == "__main__":
    main()
