#!/usr/bin/env python3
"""Create the public frozen CLIP features used by the CIFAR-2 benchmark."""

from __future__ import annotations

import argparse
from pathlib import Path

import numpy as np
import torch
from torch.utils.data import DataLoader
from torchvision.datasets import CIFAR10
from transformers import CLIPImageProcessor, CLIPModel


def collate(batch):
    images, labels = zip(*batch)
    return list(images), np.asarray(labels, dtype=np.int64)


def encode_split(
    *,
    train: bool,
    data_dir: Path,
    output_dir: Path,
    model: CLIPModel,
    processor: CLIPImageProcessor,
    device: torch.device,
    batch_size: int,
) -> None:
    dataset = CIFAR10(root=data_dir, train=train, download=True)
    loader = DataLoader(
        dataset,
        batch_size=batch_size,
        shuffle=False,
        num_workers=4,
        collate_fn=collate,
    )
    feature_parts = []
    label_parts = []
    model.eval()
    for images, labels in loader:
        pixel_values = processor(
            images=images,
            return_tensors="pt",
        ).pixel_values.to(device)
        with torch.inference_mode():
            vision = model.vision_model(pixel_values=pixel_values)
            features = model.visual_projection(vision.pooler_output)
        feature_parts.append(features.float().cpu().numpy())
        label_parts.append(labels)

    split = "train" if train else "test"
    np.save(
        output_dir / f"cifar10_{split}_clip_base_final.npy",
        np.concatenate(feature_parts),
    )
    np.save(
        output_dir / f"cifar10_{split}_labels.npy",
        np.concatenate(label_parts),
    )


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--data-dir", type=Path, default=Path("cifar_data"))
    parser.add_argument("--output-dir", type=Path, default=Path("features"))
    parser.add_argument(
        "--model",
        default="openai/clip-vit-base-patch32",
    )
    parser.add_argument("--batch-size", type=int, default=256)
    parser.add_argument(
        "--device",
        default="cuda" if torch.cuda.is_available() else "cpu",
    )
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    device = torch.device(args.device)
    processor = CLIPImageProcessor.from_pretrained(args.model)
    model = CLIPModel.from_pretrained(args.model).to(device)
    for train in (True, False):
        encode_split(
            train=train,
            data_dir=args.data_dir,
            output_dir=args.output_dir,
            model=model,
            processor=processor,
            device=device,
            batch_size=args.batch_size,
        )


if __name__ == "__main__":
    main()
