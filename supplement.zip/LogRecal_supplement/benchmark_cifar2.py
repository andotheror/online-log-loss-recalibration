#!/usr/bin/env python3
"""CIFAR-2 online recalibration with frozen public CLIP features."""

from __future__ import annotations

import argparse
import json
import os
from pathlib import Path

import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.preprocessing import normalize

from algorithm import fisher_grid, uniform_grid_like
from benchmark_synthetic import (
    aggregate,
    run_online_platt,
    run_prefix_histogram,
    run_recalibrator,
    summarize_predictions,
)


ROOT = Path(__file__).resolve().parents[2]
FEATURE_DIR = Path(
    os.environ.get(
        "LOGRECAL_FEATURE_DIR",
        ROOT / "resources/sae_coherence/features",
    )
)


def load_binary(split: str) -> tuple[np.ndarray, np.ndarray]:
    features = np.load(
        FEATURE_DIR / f"cifar10_{split}_clip_base_final.npy"
    )
    labels = np.load(FEATURE_DIR / f"cifar10_{split}_labels.npy")
    keep = np.logical_or(labels == 3, labels == 5)
    binary_labels = (labels[keep] == 5).astype(np.int64)
    return normalize(features[keep]), binary_labels


def fit_hint_model() -> tuple[np.ndarray, np.ndarray, dict[str, float]]:
    train_features, train_labels = load_binary("train")
    test_features, test_labels = load_binary("test")
    model = LogisticRegression(
        C=1.0,
        solver="lbfgs",
        max_iter=2_000,
        random_state=0,
    )
    model.fit(train_features, train_labels)
    probabilities = model.predict_proba(test_features)[:, 1]
    details = {
        "train_examples": float(train_labels.size),
        "test_examples": float(test_labels.size),
        "test_accuracy": float(
            np.mean((probabilities >= 0.5) == test_labels)
        ),
        "coefficient_norm": float(np.linalg.norm(model.coef_)),
        "iterations": float(model.n_iter_[0]),
    }
    return probabilities, test_labels, details


def make_replay_stream(
    probabilities: np.ndarray,
    labels: np.ndarray,
    passes: int,
    flip_probability: float,
    seed: int,
) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    hint_parts = []
    label_parts = []
    midpoint = passes * labels.size // 2
    position = 0
    for _ in range(passes):
        order = rng.permutation(labels.size)
        pass_hints = probabilities[order]
        pass_labels = labels[order].copy()
        locations = np.arange(position, position + labels.size)
        post_shift = locations >= midpoint
        flips = rng.random(labels.size) < flip_probability
        pass_labels[np.logical_and(post_shift, flips)] ^= 1
        hint_parts.append(pass_hints)
        label_parts.append(pass_labels)
        position += labels.size
    return np.concatenate(hint_parts), np.concatenate(label_parts)


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--epsilon", type=float, default=0.1)
    parser.add_argument("--passes", type=int, default=100)
    parser.add_argument("--seeds", type=int, default=5)
    parser.add_argument("--flip-probability", type=float, default=0.2)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("cifar2_result.json"),
    )
    args = parser.parse_args()

    probabilities, labels, model_details = fit_hint_model()
    fisher = fisher_grid(args.epsilon)
    uniform = uniform_grid_like(fisher)
    methods = [
        "hint",
        "grid_platt",
        "grid_histogram",
        "calibration_only",
        "same_size_uniform",
        "fisher",
    ]
    raw: dict[str, list[dict[str, float]]] = {
        method: [] for method in methods
    }
    for seed in range(args.seeds):
        hints, stream_labels = make_replay_stream(
            probabilities,
            labels,
            args.passes,
            args.flip_probability,
            seed,
        )
        raw["hint"].append(
            summarize_predictions(hints, hints, stream_labels, 0.0)
        )
        raw["grid_platt"].append(
            run_online_platt(hints, stream_labels, args.epsilon)
        )
        raw["grid_histogram"].append(
            run_prefix_histogram(hints, stream_labels, args.epsilon)
        )
        raw["calibration_only"].append(
            run_recalibrator(
                hints,
                stream_labels,
                args.epsilon,
                fisher,
                seed=10_000 + seed,
                calibration_only=True,
            )
        )
        raw["same_size_uniform"].append(
            run_recalibrator(
                hints,
                stream_labels,
                args.epsilon,
                uniform,
                seed=20_000 + seed,
            )
        )
        raw["fisher"].append(
            run_recalibrator(
                hints,
                stream_labels,
                args.epsilon,
                fisher,
                seed=30_000 + seed,
            )
        )

    result = {
        "settings": {
            "epsilon": args.epsilon,
            "passes": args.passes,
            "rounds": args.passes * labels.size,
            "seeds": args.seeds,
            "flip_probability": args.flip_probability,
            "feature_model": "openai/clip-vit-base-patch32",
            "hint_model": "L2-normalized frozen features plus logistic head",
        },
        "hint_model_details": model_details,
        "aggregate": {
            method: aggregate(rows) for method, rows in raw.items()
        },
        "raw": raw,
    }
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result["hint_model_details"], indent=2, sort_keys=True))
    for method in methods:
        summary = result["aggregate"][method]
        print(
            method,
            "K1",
            round(summary["calibration_k1"]["mean"], 5),
            "ECE",
            round(summary["ece_20"]["mean"], 5),
            "excess",
            round(summary["log_excess"]["mean"], 5),
        )


if __name__ == "__main__":
    main()
