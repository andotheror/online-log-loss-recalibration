#!/usr/bin/env python3
"""Evaluate the HOPS-SGD direct baseline on the frozen benchmark streams."""

from __future__ import annotations

import argparse
import json
from pathlib import Path

from benchmark_cifar2 import fit_hint_model, make_replay_stream
from benchmark_synthetic import aggregate, make_stream, run_hops_sgd


STREAMS = [
    "calibrated",
    "temperature_shift",
    "boundary_shift",
    "oscillating",
    "severe_temperature",
    "fisher_nodes",
]


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--epsilon", type=float, default=0.1)
    parser.add_argument("--rounds", type=int, default=30_000)
    parser.add_argument("--passes", type=int, default=100)
    parser.add_argument("--seeds", type=int, default=5)
    parser.add_argument("--flip-probability", type=float, default=0.2)
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("hops_result.json"),
    )
    args = parser.parse_args()

    synthetic_raw: dict[str, list[dict[str, float]]] = {
        stream: [] for stream in STREAMS
    }
    for stream_index, stream in enumerate(STREAMS):
        for seed in range(args.seeds):
            hints, labels = make_stream(
                stream,
                args.rounds,
                10_000 * stream_index + seed,
                epsilon=args.epsilon,
            )
            synthetic_raw[stream].append(
                run_hops_sgd(
                    hints,
                    labels,
                    args.epsilon,
                    seed=100_000 + 100 * stream_index + seed,
                )
            )

    probabilities, labels, model_details = fit_hint_model()
    cifar_raw: list[dict[str, float]] = []
    for seed in range(args.seeds):
        hints, stream_labels = make_replay_stream(
            probabilities,
            labels,
            args.passes,
            args.flip_probability,
            seed,
        )
        cifar_raw.append(
            run_hops_sgd(
                hints,
                stream_labels,
                args.epsilon,
                seed=200_000 + seed,
            )
        )

    result = {
        "settings": {
            "epsilon": args.epsilon,
            "synthetic_rounds": args.rounds,
            "cifar_passes": args.passes,
            "cifar_rounds": args.passes * labels.size,
            "seeds": args.seeds,
            "flip_probability": args.flip_probability,
            "expert": "online SGD Platt scaling",
            "hedger": "Foster 1999 with expert-bin preference",
        },
        "hint_model_details": model_details,
        "synthetic": {
            stream: aggregate(rows) for stream, rows in synthetic_raw.items()
        },
        "synthetic_raw": synthetic_raw,
        "cifar": aggregate(cifar_raw),
        "cifar_raw": cifar_raw,
    }
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    for stream in STREAMS:
        summary = result["synthetic"][stream]
        print(
            stream,
            "K1",
            round(summary["calibration_k1"]["mean"], 5),
            "ECE",
            round(summary["ece_20"]["mean"], 5),
            "excess",
            round(summary["log_excess"]["mean"], 5),
        )
    print(
        "cifar",
        "K1",
        round(result["cifar"]["calibration_k1"]["mean"], 5),
        "ECE",
        round(result["cifar"]["ece_20"]["mean"], 5),
        "excess",
        round(result["cifar"]["log_excess"]["mean"], 5),
    )


if __name__ == "__main__":
    main()
