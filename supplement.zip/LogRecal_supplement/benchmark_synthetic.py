#!/usr/bin/env python3
"""Synthetic finite-hint benchmarks for online log-loss recalibration."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path
import time

import numpy as np

from algorithm import (
    LogRecalibrator,
    calibration_error,
    fisher_grid,
    log_loss,
    summarize,
    tangent_gaps,
    uniform_grid_like,
)


def sigmoid(value: np.ndarray) -> np.ndarray:
    return 1.0 / (1.0 + np.exp(-value))


def logit(probability: np.ndarray) -> np.ndarray:
    return np.log(probability / (1.0 - probability))


def make_stream(
    name: str,
    rounds: int,
    seed: int,
    epsilon: float = 0.1,
) -> tuple[np.ndarray, np.ndarray]:
    rng = np.random.default_rng(seed)
    if name == "calibrated":
        levels = sigmoid(np.linspace(-6.0, 6.0, 41))
        hints = np.resize(levels, rounds)
        truth = hints
    elif name == "temperature_shift":
        levels = sigmoid(np.linspace(-7.0, 7.0, 41))
        hints = np.resize(levels, rounds)
        truth = hints.copy()
        midpoint = rounds // 2
        truth[midpoint:] = sigmoid(logit(hints[midpoint:]) / 2.2 + 0.55)
    elif name == "boundary_shift":
        levels = np.array(
            [
                1e-7,
                1e-5,
                1e-3,
                1e-2,
                0.1,
                0.5,
                0.9,
                0.99,
                0.999,
                1.0 - 1e-5,
                1.0 - 1e-7,
            ]
        )
        hints = np.resize(levels, rounds)
        truth = np.clip(0.03 + 0.94 * hints, 1e-5, 1.0 - 1e-5)
        midpoint = rounds // 2
        truth[midpoint:] = np.clip(
            0.09 + 0.82 * hints[midpoint:], 1e-5, 1.0 - 1e-5
        )
    elif name == "oscillating":
        levels = sigmoid(np.linspace(-5.0, 5.0, 31))
        hints = np.resize(levels, rounds)
        phase = (np.arange(rounds) // 2_000) % 4
        temperatures = np.array([0.65, 1.8, 0.9, 2.6])
        biases = np.array([-0.3, 0.5, 0.2, -0.55])
        truth = sigmoid(
            logit(hints) / temperatures[phase] + biases[phase]
        )
    elif name == "severe_temperature":
        levels = sigmoid(np.linspace(-8.0, 8.0, 41))
        hints = np.resize(levels, rounds)
        truth = sigmoid(logit(hints) / 3.0 + 1.0)
    elif name == "fisher_nodes":
        grid = fisher_grid(epsilon)
        count = min(20, grid.size // 2)
        indices = np.concatenate(
            [
                np.arange(count),
                np.array([grid.size // 2]),
                np.arange(grid.size - count, grid.size),
            ]
        )
        levels = grid[np.unique(indices)]
        hints = np.resize(levels, rounds)
        truth = hints
    else:
        raise ValueError(f"unknown stream: {name}")
    labels = rng.binomial(1, truth).astype(np.int64)
    return hints, labels


def binned_ece(
    predictions: np.ndarray,
    labels: np.ndarray,
    bins: int = 20,
) -> float:
    edges = np.linspace(0.0, 1.0, bins + 1)
    index = np.minimum(np.searchsorted(edges, predictions, side="right") - 1, bins - 1)
    total = predictions.size
    error = 0.0
    for bin_index in range(bins):
        mask = index == bin_index
        if np.any(mask):
            error += float(np.sum(mask)) / total * abs(
                float(np.mean(predictions[mask]) - np.mean(labels[mask]))
            )
    return error


def summarize_predictions(
    predictions: np.ndarray,
    hints: np.ndarray,
    labels: np.ndarray,
    elapsed: float,
) -> dict[str, float]:
    prediction_losses = np.where(
        labels == 1, -np.log(predictions), -np.log1p(-predictions)
    )
    hint_losses = np.where(labels == 1, -np.log(hints), -np.log1p(-hints))
    return {
        "calibration_k1": calibration_error(predictions, labels),
        "ece_20": binned_ece(predictions, labels),
        "mean_log_loss": float(np.mean(prediction_losses)),
        "mean_hint_log_loss": float(np.mean(hint_losses)),
        "log_excess": float(np.mean(prediction_losses - hint_losses)),
        "seconds": elapsed,
        "unique_predictions": float(np.unique(predictions).size),
    }


def round_to_grid(value: float, grid: np.ndarray) -> float:
    upper = int(np.searchsorted(grid, value))
    if upper == 0:
        return float(grid[0])
    if upper == grid.size:
        return float(grid[-1])
    lower = upper - 1
    if value - grid[lower] <= grid[upper] - value:
        return float(grid[lower])
    return float(grid[upper])


def run_recalibrator(
    hints: np.ndarray,
    labels: np.ndarray,
    epsilon: float,
    grid: np.ndarray,
    seed: int,
    *,
    calibration_only: bool = False,
) -> dict[str, float]:
    learner = LogRecalibrator(
        epsilon,
        grid=grid,
        seed=seed,
        meta_step=0.0 if calibration_only else None,
    )
    if calibration_only:
        learner.meta_weights[:] = (1.0, 0.0)
    started = time.perf_counter()
    records = learner.run(hints, labels)
    elapsed = time.perf_counter() - started
    result = summarize(records)
    predictions = np.array([record.prediction for record in records])
    result["ece_20"] = binned_ece(predictions, labels)
    result["seconds"] = elapsed
    result["unique_predictions"] = float(np.unique(predictions).size)
    result["levels"] = float(grid.size)
    result["mesh"] = float(np.max(np.diff(grid)))
    result["tangent_gap"] = float(np.max(tangent_gaps(grid)))
    return result


def online_sgd_platt_predictions(
    hints: np.ndarray,
    labels: np.ndarray,
    epsilon: float,
) -> np.ndarray:
    grid = fisher_grid(epsilon)
    delta = float(grid[0])
    clipped_hints = np.clip(hints, delta, 1.0 - delta)
    hint_logits = logit(clipped_hints)
    parameters = np.array([1.0, 0.0])
    predictions = np.empty_like(hints)
    for index, (feature, label) in enumerate(zip(hint_logits, labels), start=1):
        prediction = float(sigmoid(np.array(parameters[0] * feature + parameters[1])))
        prediction = float(np.clip(prediction, delta, 1.0 - delta))
        predictions[index - 1] = prediction
        gradient = (prediction - label) * np.array([feature, 1.0])
        learning_rate = 0.02 / math.sqrt(1.0 + index / 2_000.0)
        parameters -= learning_rate * np.clip(gradient, -10.0, 10.0)
        parameters[0] = np.clip(parameters[0], -5.0, 5.0)
        parameters[1] = np.clip(parameters[1], -8.0, 8.0)
    return predictions


def run_online_platt(
    hints: np.ndarray,
    labels: np.ndarray,
    epsilon: float,
) -> dict[str, float]:
    grid = fisher_grid(epsilon)
    started = time.perf_counter()
    continuous = online_sgd_platt_predictions(hints, labels, epsilon)
    predictions = np.array(
        [round_to_grid(float(prediction), grid) for prediction in continuous]
    )
    return summarize_predictions(
        predictions, hints, labels, time.perf_counter() - started
    )


def run_hops_sgd(
    hints: np.ndarray,
    labels: np.ndarray,
    epsilon: float,
    seed: int,
) -> dict[str, float]:
    """HOPS with the same online-SGD Platt expert used by our Platt baseline.

    This implements the Foster (1999) randomized game as specified and used
    by Gupta and Ramdas (2023). Each bin of the continuous Platt forecast has
    its own game. The preferred output is the midpoint of the expert's bin.
    """

    bins = int(round(1.0 / epsilon))
    if not math.isclose(bins * epsilon, 1.0, abs_tol=1e-12):
        raise ValueError("HOPS requires epsilon to divide one")

    started = time.perf_counter()
    expert_predictions = online_sgd_platt_predictions(hints, labels, epsilon)
    midpoints = (np.arange(bins, dtype=float) + 0.5) / bins
    left = np.arange(bins, dtype=float) / bins
    right = (np.arange(bins, dtype=float) + 1.0) / bins
    counts = np.zeros((bins, bins), dtype=float)
    successes = np.zeros((bins, bins), dtype=float)
    predictions = np.empty_like(hints)
    rng = np.random.default_rng(seed)

    for time_index, (expert, label) in enumerate(
        zip(expert_predictions, labels)
    ):
        pivot = min(int(expert * bins), bins - 1)
        game_counts = counts[pivot]
        game_successes = successes[pivot]
        empirical = midpoints.copy()
        observed = game_counts > 0
        empirical[observed] = (
            game_successes[observed] / game_counts[observed]
        )
        deficit = left - empirical
        excess = empirical - right
        acceptable = np.logical_and(deficit <= 0.0, excess <= 0.0)

        if acceptable[pivot]:
            output_index = pivot
        elif np.any(acceptable):
            output_index = int(np.flatnonzero(acceptable)[0])
        else:
            upper = int(np.flatnonzero(deficit > 0.0)[0])
            lower = upper - 1
            denominator = deficit[upper] + excess[lower]
            probability_lower = deficit[upper] / denominator
            output_index = (
                lower if rng.random() <= probability_lower else upper
            )

        predictions[time_index] = midpoints[output_index]
        counts[pivot, output_index] += 1.0
        successes[pivot, output_index] += float(label)

    return summarize_predictions(
        predictions, hints, labels, time.perf_counter() - started
    )


def run_prefix_histogram(
    hints: np.ndarray,
    labels: np.ndarray,
    epsilon: float,
) -> dict[str, float]:
    bins = int(math.ceil(1.0 / epsilon))
    grid = fisher_grid(epsilon)
    delta = float(grid[0])
    counts = np.zeros(bins)
    successes = np.zeros(bins)
    predictions = np.empty_like(hints)
    started = time.perf_counter()
    for index, (hint, label) in enumerate(zip(hints, labels)):
        bin_index = min(int(hint * bins), bins - 1)
        center = (bin_index + 0.5) / bins
        prediction = (successes[bin_index] + center) / (counts[bin_index] + 1.0)
        prediction = float(np.clip(prediction, delta, 1.0 - delta))
        predictions[index] = round_to_grid(prediction, grid)
        counts[bin_index] += 1.0
        successes[bin_index] += label
    return summarize_predictions(
        predictions, hints, labels, time.perf_counter() - started
    )


def aggregate(rows: list[dict[str, float]]) -> dict[str, object]:
    keys = rows[0].keys()
    return {
        key: {
            "mean": float(np.mean([row[key] for row in rows])),
            "standard_error": float(
                np.std([row[key] for row in rows], ddof=1)
                / math.sqrt(len(rows))
            )
            if len(rows) > 1
            else 0.0,
        }
        for key in keys
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--epsilon", type=float, default=0.1)
    parser.add_argument("--rounds", type=int, default=30_000)
    parser.add_argument("--seeds", type=int, default=5)
    parser.add_argument(
        "--streams",
        nargs="+",
        default=[
            "calibrated",
            "temperature_shift",
            "boundary_shift",
            "oscillating",
            "severe_temperature",
            "fisher_nodes",
        ],
    )
    parser.add_argument("--include-fine-uniform", action="store_true")
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("synthetic_result.json"),
    )
    args = parser.parse_args()

    adaptive = fisher_grid(args.epsilon)
    same_size_uniform = uniform_grid_like(adaptive)
    methods = [
        "hint",
        "grid_platt",
        "grid_histogram",
        "calibration_only",
        "same_size_uniform",
        "fisher",
    ]
    fine_uniform = None
    if args.include_fine_uniform:
        lipschitz = 1.0 / float(adaptive[0])
        intervals = 2 * math.ceil(2.0 * math.sqrt(lipschitz) / args.epsilon)
        fine_uniform = np.linspace(adaptive[0], adaptive[-1], intervals + 1)
        methods.append("lipschitz_uniform")

    raw: dict[str, dict[str, list[dict[str, float]]]] = {
        stream: {method: [] for method in methods} for stream in args.streams
    }
    for stream_index, stream in enumerate(args.streams):
        for seed in range(args.seeds):
            data_seed = 10_000 * stream_index + seed
            hints, labels = make_stream(
                stream,
                args.rounds,
                data_seed,
                epsilon=args.epsilon,
            )

            started = time.perf_counter()
            raw[stream]["hint"].append(
                summarize_predictions(
                    hints,
                    hints,
                    labels,
                    time.perf_counter() - started,
                )
            )
            raw[stream]["grid_platt"].append(
                run_online_platt(hints, labels, args.epsilon)
            )
            raw[stream]["grid_histogram"].append(
                run_prefix_histogram(hints, labels, args.epsilon)
            )
            raw[stream]["calibration_only"].append(
                run_recalibrator(
                    hints,
                    labels,
                    args.epsilon,
                    adaptive,
                    seed + 100,
                    calibration_only=True,
                )
            )
            raw[stream]["same_size_uniform"].append(
                run_recalibrator(
                    hints,
                    labels,
                    args.epsilon,
                    same_size_uniform,
                    seed + 200,
                )
            )
            raw[stream]["fisher"].append(
                run_recalibrator(
                    hints,
                    labels,
                    args.epsilon,
                    adaptive,
                    seed + 300,
                )
            )
            if fine_uniform is not None:
                raw[stream]["lipschitz_uniform"].append(
                    run_recalibrator(
                        hints,
                        labels,
                        args.epsilon,
                        fine_uniform,
                        seed + 400,
                    )
                )

    result = {
        "settings": {
            "epsilon": args.epsilon,
            "rounds": args.rounds,
            "seeds": args.seeds,
            "streams": args.streams,
        },
        "grid_geometry": {
            "fisher_levels": int(adaptive.size),
            "fisher_mesh": float(np.max(np.diff(adaptive))),
            "fisher_tangent_gap": float(np.max(tangent_gaps(adaptive))),
            "same_size_uniform_levels": int(same_size_uniform.size),
            "same_size_uniform_mesh": float(
                np.max(np.diff(same_size_uniform))
            ),
            "same_size_uniform_tangent_gap": float(
                np.max(tangent_gaps(same_size_uniform))
            ),
            "fine_uniform_levels": (
                int(fine_uniform.size) if fine_uniform is not None else None
            ),
            "fine_uniform_tangent_gap": (
                float(np.max(tangent_gaps(fine_uniform)))
                if fine_uniform is not None
                else None
            ),
        },
        "aggregate": {
            stream: {
                method: aggregate(raw[stream][method]) for method in methods
            }
            for stream in args.streams
        },
        "raw": raw,
    }
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")
    print(json.dumps(result["grid_geometry"], indent=2, sort_keys=True))
    for stream in args.streams:
        print(f"\n{stream}")
        for method in methods:
            summary = result["aggregate"][stream][method]
            print(
                method,
                "K1",
                round(summary["calibration_k1"]["mean"], 5),
                "ECE",
                round(summary["ece_20"]["mean"], 5),
                "excess",
                round(summary["log_excess"]["mean"], 5),
                "seconds",
                round(summary["seconds"]["mean"], 3),
            )


if __name__ == "__main__":
    main()
