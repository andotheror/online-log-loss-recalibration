#!/usr/bin/env python3
"""Deterministic checks for the curvature-adaptive recalibrator."""

from __future__ import annotations

import math

import numpy as np

from algorithm import (
    LogRecalibrator,
    adjacent_oracle,
    calibration_error,
    fisher_grid,
    project_two_simplex,
    summarize,
    tangent_gaps,
)


def check_oracle() -> None:
    rng = np.random.default_rng(812)
    for size in (4, 9, 25):
        for _ in range(200):
            first = rng.normal(size=size)
            second = rng.normal(size=size)
            action = adjacent_oracle(first, second)
            value_first = float(
                np.dot(action.probabilities, first[action.indices])
            )
            value_second = float(
                np.dot(action.probabilities, second[action.indices])
            )
            assert max(value_first, value_second) <= action.objective + 1e-12
            assert action.indices.size <= 2
            if action.indices.size == 2:
                assert action.indices[1] == action.indices[0] + 1


def check_projection() -> None:
    for vector in (
        np.array([0.2, 0.7]),
        np.array([-4.0, 2.0]),
        np.array([3.0, -2.0]),
    ):
        projected = project_two_simplex(vector)
        assert np.all(projected >= 0.0)
        assert abs(float(np.sum(projected)) - 1.0) < 1e-12


def check_mixture_oracle_bound() -> None:
    rng = np.random.default_rng(914)
    for epsilon in (0.2, 0.1, 0.05):
        grid = fisher_grid(epsilon)
        loss_range = math.log(1.0 / grid[0])
        mesh = float(np.max(np.diff(grid)))
        tangent_gap = float(np.max(tangent_gaps(grid)))
        loss_zero = -np.log1p(-grid)
        loss_one = -np.log(grid)
        for _ in range(2_000):
            distinguisher = rng.uniform(-1.0, 1.0, grid.size)
            alpha = float(rng.random())
            beta = 1.0 - alpha
            hint = float(rng.uniform(grid[0], grid[-1]))
            first = (
                alpha * distinguisher * grid
                + beta
                * (loss_zero + math.log1p(-hint))
                / loss_range
            )
            second = (
                alpha * distinguisher * (grid - 1.0)
                + beta * (loss_one + math.log(hint)) / loss_range
            )
            action = adjacent_oracle(first, second)
            bound = alpha * mesh + beta * tangent_gap / loss_range
            assert action.objective <= bound + 1e-12


def check_sampled_feedback() -> None:
    learner = LogRecalibrator(0.2, seed=77)
    prediction = learner.predict(0.37)
    learner.observe(1)
    changed = np.flatnonzero(
        np.abs(learner.calibration_distinguisher) > 1e-15
    )
    assert changed.size == 1
    selected = int(changed[0])
    assert learner.grid[selected] == prediction
    assert np.isclose(
        learner.calibration_distinguisher[selected],
        learner.calibration_step * (prediction - 1.0),
    )


def check_geometry_and_run() -> None:
    epsilon = 0.1
    grid = fisher_grid(epsilon)
    assert grid.size < 16.0 / epsilon
    assert np.allclose(grid, 1.0 - grid[::-1])

    rng = np.random.default_rng(19)
    rounds = 20_000
    hints = np.resize(np.array([1e-8, 0.05, 0.5, 0.95, 1.0 - 1e-8]), rounds)
    truth = np.clip(0.15 + 0.7 * hints, 0.02, 0.98)
    labels = rng.binomial(1, truth)
    learner = LogRecalibrator(epsilon, seed=23)
    records = learner.run(hints, labels)
    result = summarize(records)

    assert len(records) == rounds
    assert np.isfinite(list(result.values())).all()
    assert all(record.support_size <= 2 for record in records)
    assert result["mean_log_loss"] < 1.0
    assert 0.0 <= result["calibration_k1"] <= 1.0
    assert calibration_error(
        np.array([record.prediction for record in records]),
        labels,
    ) == result["calibration_k1"]


if __name__ == "__main__":
    check_oracle()
    check_projection()
    check_mixture_oracle_bound()
    check_sampled_feedback()
    check_geometry_and_run()
    print("all checks passed")
