#!/usr/bin/env python3
"""Calibration and log-loss frontier across meta learning rates."""

from __future__ import annotations

import argparse
import json
import math
from pathlib import Path

import numpy as np

from algorithm import LogRecalibrator, fisher_grid, summarize, uniform_grid_like
from benchmark_synthetic import aggregate, make_stream


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--epsilon", type=float, default=0.1)
    parser.add_argument("--rounds", type=int, default=30_000)
    parser.add_argument("--seeds", type=int, default=3)
    parser.add_argument(
        "--streams",
        nargs="+",
        default=["severe_temperature", "boundary_shift"],
    )
    parser.add_argument(
        "--multipliers",
        nargs="+",
        type=float,
        default=[0.25, 1.0, 4.0, 16.0, 64.0],
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=Path("frontier_result.json"),
    )
    args = parser.parse_args()

    fisher = fisher_grid(args.epsilon)
    grids = {
        "fisher": fisher,
        "same_size_uniform": uniform_grid_like(fisher),
    }
    base_step = args.epsilon**2 / (8.0 * math.log(1.0 / fisher[0]))
    raw: dict[str, dict[str, list[dict[str, float]]]] = {}
    for stream_index, stream in enumerate(args.streams):
        raw[stream] = {}
        for grid_name, grid in grids.items():
            for multiplier in args.multipliers:
                key = f"{grid_name}_x{multiplier:g}"
                rows: list[dict[str, float]] = []
                for seed in range(args.seeds):
                    hints, labels = make_stream(
                        stream,
                        args.rounds,
                        seed=100_000 * stream_index + seed,
                        epsilon=args.epsilon,
                    )
                    learner = LogRecalibrator(
                        args.epsilon,
                        grid=grid,
                        seed=200_000 * stream_index + seed,
                        meta_step=base_step * multiplier,
                    )
                    records = learner.run(hints, labels)
                    row = summarize(records)
                    row["meta_multiplier"] = float(multiplier)
                    rows.append(row)
                raw[stream][key] = rows

    result = {
        "settings": {
            "epsilon": args.epsilon,
            "rounds": args.rounds,
            "seeds": args.seeds,
            "streams": args.streams,
            "multipliers": args.multipliers,
            "base_meta_step": base_step,
        },
        "aggregate": {
            stream: {
                key: aggregate(rows) for key, rows in methods.items()
            }
            for stream, methods in raw.items()
        },
        "raw": raw,
    }
    args.output.write_text(json.dumps(result, indent=2, sort_keys=True) + "\n")

    for stream in args.streams:
        print(stream)
        for key, summary in result["aggregate"][stream].items():
            print(
                key,
                "K1",
                round(summary["calibration_k1"]["mean"], 5),
                "excess",
                round(summary["log_excess"]["mean"], 5),
                "weight",
                round(summary["final_calibration_weight"]["mean"], 5),
            )


if __name__ == "__main__":
    main()
