#!/usr/bin/env python3
"""Curvature-adaptive online recalibration for Bernoulli log loss."""

from __future__ import annotations

from dataclasses import dataclass
import math

import numpy as np


def log_loss(probability: np.ndarray | float, label: int) -> np.ndarray | float:
    probability = np.asarray(probability)
    if label == 1:
        value = -np.log(probability)
    else:
        value = -np.log1p(-probability)
    return value


def bernoulli_kl(p: np.ndarray, q: np.ndarray) -> np.ndarray:
    return p * np.log(p / q) + (1.0 - p) * np.log(
        (1.0 - p) / (1.0 - q)
    )


def tangent_gaps(grid: np.ndarray) -> np.ndarray:
    p = grid[:-1]
    r = grid[1:]
    first_orientation = bernoulli_kl(p, r) / p
    reflected_orientation = bernoulli_kl(r, p) / (1.0 - r)
    return np.where(
        r <= 0.5,
        reflected_orientation,
        np.where(
            p >= 0.5,
            first_orientation,
            np.maximum(first_orientation, reflected_orientation),
        ),
    )


def fisher_grid(epsilon: float, spacing_factor: float = 1.0 / 8.0) -> np.ndarray:
    """Return a symmetric grid uniform in arcsin(sqrt(p))."""
    angular_step = spacing_factor * epsilon
    span = math.pi / 2.0 - 2.0 * angular_step
    intervals = math.ceil(span / angular_step)
    angles = np.linspace(
        angular_step, math.pi / 2.0 - angular_step, intervals + 1
    )
    return np.sin(angles) ** 2


def uniform_grid_like(reference: np.ndarray) -> np.ndarray:
    return np.linspace(reference[0], reference[-1], reference.size)


def project_two_simplex(vector: np.ndarray) -> np.ndarray:
    """Euclidean projection of a two-vector onto the probability simplex."""
    first = np.clip((vector[0] - vector[1] + 1.0) / 2.0, 0.0, 1.0)
    return np.array([first, 1.0 - first], dtype=np.float64)


@dataclass(frozen=True)
class SparseAction:
    indices: np.ndarray
    probabilities: np.ndarray
    objective: float


def adjacent_oracle(
    first_label_payoff: np.ndarray,
    second_label_payoff: np.ndarray,
) -> SparseAction:
    """Minimize the worst label payoff over points and adjacent segments."""
    if first_label_payoff.shape != second_label_payoff.shape:
        raise ValueError("endpoint payoff arrays must have identical shapes")
    if first_label_payoff.ndim != 1 or first_label_payoff.size < 2:
        raise ValueError("the oracle requires a one-dimensional grid")

    point_values = np.maximum(first_label_payoff, second_label_payoff)
    point_index = int(np.argmin(point_values))
    best = SparseAction(
        indices=np.array([point_index], dtype=np.int64),
        probabilities=np.array([1.0], dtype=np.float64),
        objective=float(point_values[point_index]),
    )

    delta_first = np.diff(first_label_payoff)
    delta_second = np.diff(second_label_payoff)
    denominator = delta_first - delta_second
    numerator = second_label_payoff[:-1] - first_label_payoff[:-1]
    crossing = np.divide(
        numerator,
        denominator,
        out=np.zeros_like(numerator),
        where=np.abs(denominator) > 1e-15,
    )
    valid = (crossing >= 0.0) & (crossing <= 1.0)
    if not np.any(valid):
        return best

    first_at_crossing = first_label_payoff[:-1] + crossing * delta_first
    second_at_crossing = second_label_payoff[:-1] + crossing * delta_second
    edge_values = np.maximum(first_at_crossing, second_at_crossing)
    edge_values = np.where(valid, edge_values, np.inf)
    edge_index = int(np.argmin(edge_values))
    if edge_values[edge_index] < best.objective:
        weight_right = float(crossing[edge_index])
        best = SparseAction(
            indices=np.array([edge_index, edge_index + 1], dtype=np.int64),
            probabilities=np.array(
                [1.0 - weight_right, weight_right], dtype=np.float64
            ),
            objective=float(edge_values[edge_index]),
        )
    return best


@dataclass
class StepRecord:
    hint: float
    clipped_hint: float
    prediction: float
    mixed_prediction: float
    label: int
    log_loss: float
    hint_log_loss: float
    mixed_log_loss: float
    oracle_objective: float
    calibration_weight: float
    loss_weight: float
    support_size: int


class LogRecalibrator:
    """Two-objective online recalibrator with a supplied nonuniform grid.

    The calibration learner uses the sampled report so that its realized
    objective is ordinary calibration. The meta learner uses the mixed
    conditional expectation. The reported prediction is sampled from the
    action's one- or two-point support.
    """

    def __init__(
        self,
        epsilon: float,
        *,
        grid: np.ndarray | None = None,
        seed: int = 0,
        calibration_step: float | None = None,
        meta_step: float | None = None,
    ) -> None:
        if not 0.0 < epsilon < 0.5:
            raise ValueError("epsilon must lie in (0, 0.5)")
        self.epsilon = float(epsilon)
        self.grid = (
            fisher_grid(epsilon)
            if grid is None
            else np.asarray(grid, dtype=np.float64)
        )
        if (
            self.grid.ndim != 1
            or self.grid.size < 2
            or np.any(np.diff(self.grid) <= 0.0)
            or self.grid[0] <= 0.0
            or self.grid[-1] >= 1.0
        ):
            raise ValueError("grid must be strictly increasing inside (0, 1)")

        self.delta = float(min(self.grid[0], 1.0 - self.grid[-1]))
        self.loss_range = float(math.log(1.0 / self.delta))
        self.mesh = float(
            max(
                self.grid[0],
                1.0 - self.grid[-1],
                np.max(np.diff(self.grid)),
            )
        )
        self.tangent_gap = float(np.max(tangent_gaps(self.grid)))
        self.calibration_tolerance = self.mesh
        self.normalized_loss_tolerance = self.tangent_gap / self.loss_range

        self.calibration_step = (
            float(calibration_step)
            if calibration_step is not None
            else self.epsilon / 4.0
        )
        self.meta_step = (
            float(meta_step)
            if meta_step is not None
            else self.epsilon**2 / (8.0 * self.loss_range)
        )

        self.calibration_distinguisher = np.zeros_like(self.grid)
        self.meta_weights = np.array([0.0, 1.0], dtype=np.float64)
        self.rng = np.random.default_rng(seed)

        self._loss_zero = -np.log1p(-self.grid)
        self._loss_one = -np.log(self.grid)
        self.records: list[StepRecord] = []
        self._pending: tuple[
            float,
            float,
            SparseAction,
            int,
            float,
            float,
            np.ndarray,
            np.ndarray,
        ] | None = None

    def _clip_hint(self, hint: float) -> float:
        return float(np.clip(hint, self.grid[0], self.grid[-1]))

    def predict(self, hint: float) -> float:
        if self._pending is not None:
            raise RuntimeError("observe must be called before the next prediction")
        if not 0.0 <= hint <= 1.0:
            raise ValueError("hint must lie in [0, 1]")

        clipped_hint = self._clip_hint(float(hint))
        alpha, beta = self.meta_weights
        loss_zero_hint = -math.log1p(-clipped_hint)
        loss_one_hint = -math.log(clipped_hint)

        calibration_zero = self.calibration_distinguisher * self.grid
        calibration_one = self.calibration_distinguisher * (self.grid - 1.0)
        normalized_loss_zero = (
            self._loss_zero - loss_zero_hint
        ) / self.loss_range
        normalized_loss_one = (
            self._loss_one - loss_one_hint
        ) / self.loss_range

        first_label_payoff = (
            alpha * calibration_zero + beta * normalized_loss_zero
        )
        second_label_payoff = (
            alpha * calibration_one + beta * normalized_loss_one
        )
        action = adjacent_oracle(first_label_payoff, second_label_payoff)
        local_choice = int(
            self.rng.choice(action.indices.size, p=action.probabilities)
        )
        selected_index = int(action.indices[local_choice])
        prediction = float(self.grid[selected_index])
        mixed_prediction = float(
            np.dot(action.probabilities, self.grid[action.indices])
        )
        self._pending = (
            float(hint),
            clipped_hint,
            action,
            selected_index,
            prediction,
            mixed_prediction,
            first_label_payoff,
            second_label_payoff,
        )
        return prediction

    def observe(self, label: int) -> StepRecord:
        if self._pending is None:
            raise RuntimeError("predict must be called before observe")
        if label not in (0, 1):
            raise ValueError("label must be zero or one")

        (
            hint,
            clipped_hint,
            action,
            selected_index,
            prediction,
            mixed_prediction,
            _,
            _,
        ) = self._pending
        indices = action.indices
        probabilities = action.probabilities

        # The approachability learners must receive the sampled point-mass
        # payoff. Its conditional expectation is the oracle's mixed payoff,
        # while its realized coordinates define ordinary calibration.
        calibration_feedback = np.zeros_like(self.grid)
        calibration_feedback[selected_index] = prediction - label
        mixed_calibration_feedback = np.zeros_like(self.grid)
        mixed_calibration_feedback[indices] = probabilities * (
            self.grid[indices] - label
        )
        loss_grid = self._loss_one if label == 1 else self._loss_zero
        clipped_hint_loss = float(log_loss(clipped_hint, label))
        mixed_normalized_loss_feedback = float(
            np.dot(
                probabilities,
                loss_grid[indices] - clipped_hint_loss,
            )
            / self.loss_range
        )

        old_distinguisher = self.calibration_distinguisher.copy()
        meta_feedback = np.array(
            [
                float(
                    np.dot(
                        old_distinguisher,
                        mixed_calibration_feedback,
                    )
                )
                - self.calibration_tolerance,
                mixed_normalized_loss_feedback
                - self.normalized_loss_tolerance,
            ],
            dtype=np.float64,
        )

        self.calibration_distinguisher = np.clip(
            old_distinguisher
            + self.calibration_step * calibration_feedback,
            -1.0,
            1.0,
        )
        self.meta_weights = project_two_simplex(
            self.meta_weights + self.meta_step * meta_feedback
        )

        mixed_loss = float(np.dot(probabilities, loss_grid[indices]))
        record = StepRecord(
            hint=hint,
            clipped_hint=clipped_hint,
            prediction=prediction,
            mixed_prediction=mixed_prediction,
            label=label,
            log_loss=float(log_loss(prediction, label)),
            hint_log_loss=float(log_loss(hint, label)),
            mixed_log_loss=mixed_loss,
            oracle_objective=action.objective,
            calibration_weight=float(self.meta_weights[0]),
            loss_weight=float(self.meta_weights[1]),
            support_size=int(indices.size),
        )
        self.records.append(record)
        self._pending = None
        return record

    def run(self, hints: np.ndarray, labels: np.ndarray) -> list[StepRecord]:
        hints = np.asarray(hints, dtype=np.float64)
        labels = np.asarray(labels, dtype=np.int64)
        if hints.shape != labels.shape or hints.ndim != 1:
            raise ValueError("hints and labels must be same-length vectors")
        for hint, label in zip(hints, labels):
            self.predict(float(hint))
            self.observe(int(label))
        return self.records


def calibration_error(
    predictions: np.ndarray,
    labels: np.ndarray,
) -> float:
    predictions = np.asarray(predictions)
    labels = np.asarray(labels)
    if predictions.shape != labels.shape:
        raise ValueError("predictions and labels must have the same shape")
    total = predictions.size
    residual = 0.0
    for value in np.unique(predictions):
        mask = predictions == value
        residual += abs(float(np.sum(value - labels[mask])))
    return residual / total


def summarize(records: list[StepRecord]) -> dict[str, float]:
    prediction = np.array([r.prediction for r in records])
    label = np.array([r.label for r in records])
    log_losses = np.array([r.log_loss for r in records])
    hint_losses = np.array([r.hint_log_loss for r in records])
    mixed_losses = np.array([r.mixed_log_loss for r in records])
    return {
        "rounds": float(len(records)),
        "calibration_k1": calibration_error(prediction, label),
        "mean_log_loss": float(np.mean(log_losses)),
        "mean_hint_log_loss": float(np.mean(hint_losses)),
        "log_excess": float(np.mean(log_losses - hint_losses)),
        "mixed_log_excess": float(np.mean(mixed_losses - hint_losses)),
        "mean_support_size": float(
            np.mean([r.support_size for r in records])
        ),
        "final_calibration_weight": records[-1].calibration_weight,
        "final_loss_weight": records[-1].loss_weight,
    }
